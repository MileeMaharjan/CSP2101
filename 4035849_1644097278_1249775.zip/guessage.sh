#!/bin/bash


#function declearation
random_age(){
#finding random numbers from 1 to 50
rand_age=$((RANDOM %50+1))
}


random_age

#since the random age range is 20 - 70,
# 20 is added with the number

add=20
new_rand_age=$((rand_age + add))

flag=0
# using while loop to take user input untill
# correct are is entered
while [ $flag -ne 1 ]
do

echo "Enter a age to guess: "
read age

if (("$age" < "$new_rand_age"))
then
	echo "The guess is low. Try again."
elif (("$age" == "$new_rand_age")) 
then
	echo "Congrats you guessed the correct age"
	flag=1
else
	echo "The guess is high. Try again."
fi

done
